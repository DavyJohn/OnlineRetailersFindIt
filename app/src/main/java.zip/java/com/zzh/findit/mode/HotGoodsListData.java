package com.zzh.findit.mode;

/**
 * Created by 腾翔信息 on 2018/2/28.
 */

public class HotGoodsListData{
    private String goods_id;
    private String sold_number;
    private String name;
    private String small;
    private String buy_count;
    private String price;

    public String getGoods_id() {
        return goods_id;
    }

    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id;
    }

    public String getSold_number() {
        return sold_number;
    }

    public void setSold_number(String sold_number) {
        this.sold_number = sold_number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSmall() {
        return small;
    }

    public void setSmall(String small) {
        this.small = small;
    }

    public String getBuy_count() {
        return buy_count;
    }

    public void setBuy_count(String buy_count) {
        this.buy_count = buy_count;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
