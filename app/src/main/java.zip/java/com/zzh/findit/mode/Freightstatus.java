package com.zzh.findit.mode;

/**
 * Created by 腾翔信息 on 2017/7/19.
 */

public class Freightstatus {

    private boolean isSelect = true;

    public boolean isSelect() {
        return isSelect;
    }

    public void setSelect(boolean select) {
        isSelect = select;
    }
}
