package com.zzh.findit.mode;

import java.util.List;

/**
 * Created by 腾翔信息 on 2018/2/28.
 */

public class RtMode {
    private String result;
    private String message;
    private RtData data;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public RtData getData() {
        return data;
    }

    public void setData(RtData data) {
        this.data = data;
    }

}
