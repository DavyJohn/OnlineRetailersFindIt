package com.zzh.findit.widget.listener;

import android.view.View;

/**
 * Created by Sai on 16/1/15.
 */
public interface SnappingStepperValueChangeListener {
    public void onValueChange(View view, int value);
}
