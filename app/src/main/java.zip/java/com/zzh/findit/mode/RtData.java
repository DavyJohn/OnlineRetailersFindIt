package com.zzh.findit.mode;

import java.util.List;

/**
 * Created by 腾翔信息 on 2018/2/28.
 */

public class RtData {

    private List<RtCatList> oneCatList;

    public List<RtCatList> getOneCatList() {
        return oneCatList;
    }

    public void setOneCatList(List<RtCatList> oneCatList) {
        this.oneCatList = oneCatList;
    }
}
