package com.zzh.findit.mode;

/**
 * Created by 腾翔信息 on 2017/8/28.
 */

public class BaseMode {
    private String result;
    private String message;
    private String data;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
