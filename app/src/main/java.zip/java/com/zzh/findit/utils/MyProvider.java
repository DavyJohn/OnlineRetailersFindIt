package com.zzh.findit.utils;

import android.support.v4.content.FileProvider;

/**
 * Created by 腾翔信息 on 2017/9/29.
 */

public class MyProvider extends FileProvider {
}
